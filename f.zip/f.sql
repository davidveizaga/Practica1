-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.30 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para mydb
CREATE DATABASE IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mydb`;

-- Volcando estructura para tabla mydb.alumno_se_matricula_asignatura
CREATE TABLE IF NOT EXISTS `alumno_se_matricula_asignatura` (
  `persona_id` int NOT NULL,
  `id_asignatura` int NOT NULL,
  `id_curso_escolar` int NOT NULL,
  PRIMARY KEY (`persona_id`,`id_asignatura`,`id_curso_escolar`) USING BTREE,
  KEY `fk_alumno_se_matricula_asignatura_asignatura1_idx` (`id_asignatura`),
  KEY `fk_alumno_se_matricula_asignatura_curso_escolar1_idx` (`id_curso_escolar`),
  CONSTRAINT `fk_alumno_se_matricula_asignatura_asignatura1` FOREIGN KEY (`id_asignatura`) REFERENCES `asignatura` (`id`),
  CONSTRAINT `fk_alumno_se_matricula_asignatura_curso_escolar1` FOREIGN KEY (`id_curso_escolar`) REFERENCES `curso_escolar` (`id`),
  CONSTRAINT `fk_alumno_se_matricula_asignatura_persona1` FOREIGN KEY (`persona_id`) REFERENCES `persona` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla mydb.asignatura
CREATE TABLE IF NOT EXISTS `asignatura` (
  `id` int NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `creditos` float NOT NULL,
  `tipo` enum('básica','obligatoria','optativa') NOT NULL,
  `curso` tinyint NOT NULL,
  `cuatrimestre` tinyint NOT NULL,
  `profesor_id_profesor` int NOT NULL,
  `grado_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_asignatura_profesor_idx` (`profesor_id_profesor`),
  KEY `fk_asignatura_grado1_idx` (`grado_id`),
  CONSTRAINT `fk_asignatura_grado1` FOREIGN KEY (`grado_id`) REFERENCES `grado` (`id`),
  CONSTRAINT `fk_asignatura_profesor` FOREIGN KEY (`profesor_id_profesor`) REFERENCES `profesor` (`profesor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla mydb.curso_escolar
CREATE TABLE IF NOT EXISTS `curso_escolar` (
  `id` int NOT NULL,
  `anyo_inicio` year NOT NULL,
  `anyo_fin` year NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla mydb.departamento
CREATE TABLE IF NOT EXISTS `departamento` (
  `id` int NOT NULL,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla mydb.grado
CREATE TABLE IF NOT EXISTS `grado` (
  `id` int NOT NULL,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla mydb.persona
CREATE TABLE IF NOT EXISTS `persona` (
  `id` int NOT NULL,
  `nif` varchar(9) DEFAULT NULL,
  `nombre` varchar(25) NOT NULL,
  `apellido1` varchar(50) NOT NULL,
  `apellido2` varchar(50) DEFAULT NULL,
  `ciudad` varchar(25) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `telefono` varchar(9) DEFAULT NULL,
  `fecha_nacimiento` date NOT NULL,
  `sexo` enum('H','M') NOT NULL,
  `tipo` enum('profesor','alumno') NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `nif_UNIQUE` (`nif`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla mydb.profesor
CREATE TABLE IF NOT EXISTS `profesor` (
  `profesor_id` int NOT NULL,
  `id_departamento` int NOT NULL,
  `alumno_id` int NOT NULL,
  PRIMARY KEY (`profesor_id`,`alumno_id`) USING BTREE,
  UNIQUE KEY `id_profesor_UNIQUE` (`profesor_id`) USING BTREE,
  KEY `fk_profesor_departamento1_idx` (`id_departamento`) USING BTREE,
  KEY `fk_profesor_persona1_idx` (`alumno_id`) USING BTREE,
  CONSTRAINT `fk_profesor_departamento1` FOREIGN KEY (`id_departamento`) REFERENCES `departamento` (`id`),
  CONSTRAINT `fk_profesor_persona1` FOREIGN KEY (`alumno_id`) REFERENCES `persona` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- La exportación de datos fue deseleccionada.

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
